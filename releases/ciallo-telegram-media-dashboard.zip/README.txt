Ciallo Telegram Media Worker — Dashboard 上传包
================================================

本 zip 仅含预构建 worker.js，无 wrangler.toml，适合 Cloudflare 网页「上传」。

上传步骤：
1. Cloudflare Dashboard → Workers & Pages → Create → Create Worker
2. 进入 Worker → 右上角 Edit code / 或 Settings → 用「Upload」上传本 zip
   （若界面是「Deploy from repository」请改用本包的「Upload assets / Upload Worker」）
3. Settings → Variables and Secrets 添加：

   Secret（加密）:
     TELEGRAM_BOT_TOKEN   = BotFather Token
     TELEGRAM_CHAT_ID     = 群/频道 ID（如 -100...）
     UPLOAD_TOKEN         = 自设上传口令（建议）
     ALLOWED_ORIGINS      = 可选，CORS 白名单逗号分隔

   Variable（明文）:
     MAX_UPLOAD_BYTES     = 20971520

4. Save and Deploy
5. 复制 Worker 公网 URL 到 Ciallo 管理页「Media Base URL」
   Upload Token 填 UPLOAD_TOKEN

接口：
  GET  /healthz
  POST /v1/upload   (multipart field: file)
  GET  /v1/media/:fileId

注意：若 Dashboard 仍提示不支持 zip，请改用 wrangler：
  见 workers/telegram-media/DEPLOY.md
