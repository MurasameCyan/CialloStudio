Ciallo Telegram Media — Cloudflare Pages 直传包
================================================

内容（无构建、无 wrangler.toml）：
  index.html
  _worker.js

部署步骤：
1. https://dash.cloudflare.com/ → Workers & Pages → Create
2. 选择「Pages」→ Upload assets / Direct Upload
3. 项目名例如 ciallo-media
4. 上传本 zip（或解压后拖入文件夹）
5. Deploy site
6. Settings → Environment variables → Production 添加：

   TELEGRAM_BOT_TOKEN   (Secret)  Bot Token
   TELEGRAM_CHAT_ID     (Secret)  群 ID，如 -100...
   UPLOAD_TOKEN         (Secret)  上传口令（建议）
   ALLOWED_ORIGINS      (可选)    CORS 白名单，逗号分隔
   MAX_UPLOAD_BYTES     (可选)    默认 20971520（20 MB）
                                  存视频建议 52428800（50 MB，Telegram
                                  bot 接口硬上限）；1080p 长视频易超 20 MB

7. 保存后若变量是后加的，点「Retry deployment」或重新 Deploy
8. 公网地址形如：https://ciallo-media.pages.dev
   填到 Ciallo Studio「Media Base URL」
   Upload Token 填 UPLOAD_TOKEN

自检：
  https://你的项目.pages.dev/healthz

说明：
  Pages 的 _worker.js 会处理 API；静态 index.html 仅作说明页。
  图片与视频（mp4/webm/mov）都走 POST /v1/upload；上传一律用 sendDocument
  保真，Telegram 可能把 mp4 转成 video 类型消息，worker 两种都能接。
