var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// src/index.ts
var TG_API = "https://api.telegram.org";
function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      ...headers
    }
  });
}
__name(json, "json");
function err(status, code, message, cors = {}) {
  const body = { error: { code, message } };
  return json(body, status, cors);
}
__name(err, "err");
function parseOrigins(raw) {
  if (!raw?.trim()) return [];
  return raw.split(",").map((s) => s.trim()).filter(Boolean);
}
__name(parseOrigins, "parseOrigins");
function corsHeaders(env, request) {
  const h = new Headers();
  h.set("access-control-allow-methods", "GET, POST, OPTIONS");
  h.set("access-control-allow-headers", "authorization, content-type, x-ciallo-upload-token");
  h.set("access-control-max-age", "86400");
  h.set("access-control-expose-headers", "content-type, content-length, cache-control");
  const origin = request.headers.get("origin") || "";
  const allowed = parseOrigins(env.ALLOWED_ORIGINS);
  if (allowed.length === 0) {
    h.set("access-control-allow-origin", origin || "*");
    if (origin) h.set("vary", "Origin");
  } else if (origin && allowed.includes(origin)) {
    h.set("access-control-allow-origin", origin);
    h.set("vary", "Origin");
  } else if (!origin) {
    h.set("access-control-allow-origin", allowed[0] || "*");
  }
  return h;
}
__name(corsHeaders, "corsHeaders");
function withCors(res, cors) {
  const out = new Response(res.body, res);
  cors.forEach((v, k) => out.headers.set(k, v));
  return out;
}
__name(withCors, "withCors");
function maxBytes(env) {
  const n = Number(env.MAX_UPLOAD_BYTES || 20 * 1024 * 1024);
  return Number.isFinite(n) && n > 0 ? Math.min(n, 50 * 1024 * 1024) : 20 * 1024 * 1024;
}
__name(maxBytes, "maxBytes");
function requireSecrets(env) {
  if (!env.TELEGRAM_BOT_TOKEN?.trim()) return "TELEGRAM_BOT_TOKEN not configured";
  if (!env.TELEGRAM_CHAT_ID?.trim()) return "TELEGRAM_CHAT_ID not configured";
  return null;
}
__name(requireSecrets, "requireSecrets");
function authorizeUpload(env, request) {
  const expected = env.UPLOAD_TOKEN?.trim();
  if (!expected) return true;
  const auth = request.headers.get("authorization") || "";
  if (auth.toLowerCase().startsWith("bearer ")) {
    return auth.slice(7).trim() === expected;
  }
  const alt = request.headers.get("x-ciallo-upload-token") || "";
  return alt.trim() === expected;
}
__name(authorizeUpload, "authorizeUpload");
async function tgApi(token, method, init) {
  const url = `${TG_API}/bot${token}/${method}`;
  const res = await fetch(url, init);
  const data = await res.json();
  if (!data.ok || data.result === void 0) {
    throw new Error(data.description || `Telegram API ${method} failed (${res.status})`);
  }
  return data.result;
}
__name(tgApi, "tgApi");
function pickFileId(msg) {
  if (msg.document?.file_id) return { fileId: msg.document.file_id, kind: "document" };
  if (msg.photo?.length) {
    const best = [...msg.photo].sort((a, b) => (b.file_size || 0) - (a.file_size || 0))[0];
    if (best?.file_id) return { fileId: best.file_id, kind: "photo" };
  }
  return null;
}
__name(pickFileId, "pickFileId");
async function readUploadBytes(request, limit) {
  const ctype = (request.headers.get("content-type") || "").toLowerCase();
  if (ctype.includes("multipart/form-data")) {
    const form = await request.formData();
    const file = form.get("file") ?? form.get("image") ?? form.get("photo");
    if (!(file instanceof File)) {
      throw new Error("multipart \u9700\u5B57\u6BB5 file / image / photo");
    }
    if (file.size > limit) throw new Error(`\u6587\u4EF6\u8FC7\u5927\uFF08\u4E0A\u9650 ${limit} \u5B57\u8282\uFF09`);
    const buf2 = new Uint8Array(await file.arrayBuffer());
    return {
      bytes: buf2,
      filename: file.name || "image.bin",
      contentType: file.type || "application/octet-stream"
    };
  }
  const buf = new Uint8Array(await request.arrayBuffer());
  if (buf.byteLength === 0) throw new Error("\u7A7A\u8BF7\u6C42\u4F53");
  if (buf.byteLength > limit) throw new Error(`\u6587\u4EF6\u8FC7\u5927\uFF08\u4E0A\u9650 ${limit} \u5B57\u8282\uFF09`);
  const contentType = request.headers.get("content-type") || "application/octet-stream";
  const ext = contentType.includes("png") ? "png" : contentType.includes("webp") ? "webp" : contentType.includes("gif") ? "gif" : contentType.includes("jpeg") || contentType.includes("jpg") ? "jpg" : "bin";
  return { bytes: buf, filename: `upload.${ext}`, contentType };
}
__name(readUploadBytes, "readUploadBytes");
function publicMediaUrl(request, fileId) {
  const u = new URL(request.url);
  return `${u.origin}/v1/media/${encodeURIComponent(fileId)}`;
}
__name(publicMediaUrl, "publicMediaUrl");
async function handleUpload(request, env, cors) {
  const missing = requireSecrets(env);
  if (missing) return withCors(err(500, "config", missing), cors);
  if (!authorizeUpload(env, request)) {
    return withCors(err(401, "unauthorized", "\u9700\u8981\u6709\u6548\u7684\u4E0A\u4F20\u51ED\u8BC1"), cors);
  }
  if (request.method !== "POST") {
    return withCors(err(405, "method_not_allowed", "\u4EC5\u652F\u6301 POST"), cors);
  }
  const limit = maxBytes(env);
  let payload;
  try {
    payload = await readUploadBytes(request, limit);
  } catch (e) {
    return withCors(
      err(400, "bad_request", e instanceof Error ? e.message : "\u8BFB\u53D6\u4E0A\u4F20\u5931\u8D25"),
      cors
    );
  }
  const token = env.TELEGRAM_BOT_TOKEN.trim();
  const chatId = env.TELEGRAM_CHAT_ID.trim();
  const ab = payload.bytes.buffer.slice(
    payload.bytes.byteOffset,
    payload.bytes.byteOffset + payload.bytes.byteLength
  );
  const form = new FormData();
  form.set("chat_id", chatId);
  form.set(
    "document",
    new Blob([ab], { type: payload.contentType }),
    payload.filename
  );
  form.set("disable_notification", "true");
  form.set(
    "caption",
    `ciallo-media \xB7 ${payload.filename} \xB7 ${payload.bytes.byteLength}B \xB7 ${(/* @__PURE__ */ new Date()).toISOString()}`
  );
  let message;
  try {
    message = await tgApi(token, "sendDocument", { method: "POST", body: form });
  } catch (e) {
    return withCors(
      err(502, "telegram_upload_failed", e instanceof Error ? e.message : "Telegram \u4E0A\u4F20\u5931\u8D25"),
      cors
    );
  }
  const picked = pickFileId(message);
  if (!picked) {
    return withCors(err(502, "telegram_no_file", "Telegram \u672A\u8FD4\u56DE file_id"), cors);
  }
  const url = publicMediaUrl(request, picked.fileId);
  return withCors(
    json({
      mediaId: picked.fileId,
      fileId: picked.fileId,
      kind: picked.kind,
      url,
      messageId: message.message_id,
      size: payload.bytes.byteLength,
      contentType: payload.contentType,
      filename: payload.filename
    }),
    cors
  );
}
__name(handleUpload, "handleUpload");
async function handleMediaGet(request, env, cors, fileId) {
  const missing = requireSecrets(env);
  if (missing) return withCors(err(500, "config", missing), cors);
  if (!fileId) return withCors(err(400, "bad_request", "\u7F3A\u5C11 file_id"), cors);
  const token = env.TELEGRAM_BOT_TOKEN.trim();
  let file;
  try {
    file = await tgApi(token, "getFile", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ file_id: fileId })
    });
  } catch (e) {
    return withCors(
      err(404, "not_found", e instanceof Error ? e.message : "\u6587\u4EF6\u4E0D\u5B58\u5728"),
      cors
    );
  }
  if (!file.file_path) {
    return withCors(err(404, "not_found", "Telegram \u672A\u8FD4\u56DE file_path"), cors);
  }
  const tgUrl = `${TG_API}/file/bot${token}/${file.file_path}`;
  const upstream = await fetch(tgUrl);
  if (!upstream.ok) {
    return withCors(
      err(502, "telegram_fetch_failed", `\u62C9\u53D6 Telegram \u6587\u4EF6\u5931\u8D25 HTTP ${upstream.status}`),
      cors
    );
  }
  const headers = new Headers(cors);
  const ct = upstream.headers.get("content-type") || guessMime(file.file_path);
  headers.set("content-type", ct);
  headers.set("cache-control", "public, max-age=31536000, immutable");
  if (file.file_size) headers.set("content-length", String(file.file_size));
  headers.set("x-ciallo-media-id", fileId);
  return new Response(upstream.body, { status: 200, headers });
}
__name(handleMediaGet, "handleMediaGet");
function guessMime(path) {
  const p = path.toLowerCase();
  if (p.endsWith(".png")) return "image/png";
  if (p.endsWith(".webp")) return "image/webp";
  if (p.endsWith(".gif")) return "image/gif";
  if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
  return "application/octet-stream";
}
__name(guessMime, "guessMime");
function route(pathname) {
  if (pathname === "/" || pathname === "") return { name: "root" };
  if (pathname === "/healthz" || pathname === "/v1/healthz") return { name: "health" };
  if (pathname === "/v1/upload" || pathname === "/upload") return { name: "upload" };
  const m = pathname.match(/^\/v1\/media\/(.+)$/) || pathname.match(/^\/media\/(.+)$/) || pathname.match(/^\/m\/(.+)$/);
  if (m?.[1]) {
    try {
      return { name: "media", fileId: decodeURIComponent(m[1]) };
    } catch {
      return { name: "media", fileId: m[1] };
    }
  }
  return null;
}
__name(route, "route");
var index_default = {
  async fetch(request, env) {
    const cors = corsHeaders(env, request);
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }
    const url = new URL(request.url);
    const matched = route(url.pathname);
    if (!matched) {
      return withCors(err(404, "not_found", "\u672A\u77E5\u8DEF\u5F84"), cors);
    }
    if (matched.name === "root") {
      return withCors(
        json({
          service: "ciallo-telegram-media",
          endpoints: ["GET /healthz", "POST /v1/upload", "GET /v1/media/:fileId"]
        }),
        cors
      );
    }
    if (matched.name === "health") {
      const configured = !requireSecrets(env);
      return withCors(
        json({
          ok: true,
          telegramConfigured: configured,
          uploadAuth: Boolean(env.UPLOAD_TOKEN?.trim())
        }),
        cors
      );
    }
    if (matched.name === "upload") {
      return handleUpload(request, env, cors);
    }
    if (matched.name === "media" && matched.fileId) {
      if (request.method !== "GET" && request.method !== "HEAD") {
        return withCors(err(405, "method_not_allowed", "\u4EC5\u652F\u6301 GET"), cors);
      }
      return handleMediaGet(request, env, cors, matched.fileId);
    }
    return withCors(err(404, "not_found", "\u672A\u77E5\u8DEF\u5F84"), cors);
  }
};
export {
  index_default as default
};
//# sourceMappingURL=index.js.map
